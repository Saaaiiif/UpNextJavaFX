package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class TestController {

    @FXML
    private Button btnAjout;

    @FXML
    private Label lblName;

    @FXML
    private TableView<?> tableRecs;

    @FXML
    private TextField txtName;

    @FXML
    void AjouterName(ActionEvent event) {

    }

}
