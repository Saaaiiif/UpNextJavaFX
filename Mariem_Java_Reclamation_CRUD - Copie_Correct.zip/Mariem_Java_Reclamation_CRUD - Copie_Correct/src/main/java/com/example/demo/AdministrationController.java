package com.example.demo;

import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.*;
import java.time.LocalDate;
import java.util.ResourceBundle;

import Entities.Reclamation;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import utils.MyDB;


public class AdministrationController {
//api key open router deepseek LLama : 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

    @FXML
    private Label rec_home;
/*
    @FXML
    void GoToReclamation(MouseEvent event) {

    }*/
    @FXML
    public void GoToReclamation(javafx.scene.input.MouseEvent mouseEvent) {
        try {
            // Charger le fichier FXML de la page de gestion des réclamations
            FXMLLoader loader = new FXMLLoader(getClass().getResource("GestionReclamationAdmin.fxml"));
            Parent root = loader.load();

            // Obtenir la scène actuelle
            Stage stage = (Stage) rec_home.getScene().getWindow();

            // Remplacer la scène par la nouvelle page
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("❌ Erreur lors du chargement de la page GestionReclamation.fxml");
        }
    }
}
