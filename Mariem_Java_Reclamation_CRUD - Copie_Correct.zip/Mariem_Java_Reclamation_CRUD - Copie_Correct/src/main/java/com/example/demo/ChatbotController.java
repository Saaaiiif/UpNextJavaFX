package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.entity.StringEntity;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ChatbotController {

    @FXML
    private TextArea chatArea;   // Zone d'affichage des messages
    @FXML
    private TextField messageField;  // Champ de texte pour entrer un message
    @FXML
    private Button sendButton;  // Bouton d'envoi

    // Clé API OpenRouter (remplacez par votre clé personnelle)
    private static final String API_KEY = "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";

    // URL de l'API OpenRouter pour le modèle deepseek
    private static final String API_URL = "https://openrouter.ai/api/v1/chat/completions";

    // Méthode pour envoyer un message
    @FXML
    public void sendMessage(ActionEvent event) {
        String message = messageField.getText();  // Récupère le message tapé par l'utilisateur

        if (!message.trim().isEmpty()) {
            // Affiche le message de l'utilisateur dans la zone de chat
            chatArea.appendText("Vous: " + message + "\n");

            // Appel à l'API OpenRouter pour obtenir la réponse du modèle
            String response = getChatbotResponse(message);

            // Affiche la réponse du chatbot
            chatArea.appendText("Chatbot: " + response + "\n");

            // Efface le champ de texte après l'envoi
            messageField.clear();
        }
    }

    // Méthode pour obtenir la réponse du chatbot via l'API OpenRouter
    // Méthode pour obtenir la réponse du chatbot via l'API OpenRouter
    private String getChatbotResponse(String message) {
        String response = "";

        try {
            // Crée une instance de HttpClient
            CloseableHttpClient httpClient = HttpClients.createDefault();
            HttpPost request = new HttpPost(API_URL);

            // Ajoute l'en-tête d'autorisation avec votre clé API
            request.setHeader("Authorization", "Bearer " + API_KEY);

            // Ajoute les en-têtes supplémentaires
            request.setHeader("HTTP-Referer", "<YOUR_SITE_URL>");
            request.setHeader("X-Title", "<YOUR_SITE_NAME>");

            // Crée le corps de la requête avec le message de l'utilisateur
            String jsonBody = "{\"model\": \"deepseek/deepseek-r1-distill-llama-70b:free\", " +
                    "\"messages\": [{\"role\": \"user\", \"content\": \"" + message + "\"}]}";
            StringEntity entity = new StringEntity(jsonBody);
            request.setEntity(entity);

            // Exécute la requête HTTP
            HttpResponse httpResponse = httpClient.execute(request);

            // Récupère la réponse du serveur
            BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));
            StringBuilder responseBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                responseBuilder.append(line);
            }

            // Affiche la réponse brute pour déboguer
            System.out.println("Réponse brute de l'API: " + responseBuilder.toString());

            // Utilise Jackson pour parser la réponse JSON
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonResponse = objectMapper.readTree(responseBuilder.toString());

            // Récupère la première réponse du modèle
            response = jsonResponse.get("choices").get(0).get("message").get("content").asText();

            // Ferme l'HttpClient
            httpClient.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return response;
    }




}
