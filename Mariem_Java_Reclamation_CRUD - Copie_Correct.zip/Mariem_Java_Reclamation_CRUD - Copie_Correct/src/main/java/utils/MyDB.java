package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyDB {
    //private static final String URL = "jdbc:mysql://localhost:3306/reclamation_java";
    //private static final String USER = "root";
    //private static final String PASSWORD = "";

    private static MyDB instance;
    private Connection connection;

    private MyDB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  // Enregistrement explicite du driver
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/pi_mariem", "root", "");
            System.out.println("Connection Established!");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver MySQL introuvable !");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Erreur de connexion à la base de données !");
            e.printStackTrace();
        }

    }

    public static MyDB getInstance() {
        if (instance == null) {
            instance = new MyDB();
        }
        return instance;
    }


    public Connection getConnection() {
        return connection;
    }
}
